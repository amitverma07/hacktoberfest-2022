const deckCard = document.getElementById('cards');
const deckCard1 = document.getElementsByClassName('card');
const leftcard = document.querySelector('#next-card');
let card = document.getElementsByClassName('card');
let arry = Array.from(card);

let arry2 = ['fas fa-bell', 'fas fa-atom', 'fas fa-frog', 'fas fa-cogs', 'fas fa-anchor', 'fas fa-fan', 'fas fa-bolt', 'fas fa-hat-wizard', 'fas fa-apple-alt', 'fas fa-bomb', 'fas fa-brain', 'fas fa-feather-alt'];

let nextElement = document.getElementById('next-card');
let newList = nextElement.firstElementChild.className;

let count = document.getElementById('score');
count.innerText = 0;

const masterCard = document.getElementsByClassName('matched');
const allCard = document.getElementsByClassName('card');

// To show the cards, getting next element and counting the moves

deckCard.addEventListener("click", function (e) {

  let cardData = e.target.firstElementChild.className;
  if (e.target.className === 'card') {
    e.target.classList.add('show');
    count.innerText = parseInt(count.innerText) + 1;
  }

  setTimeout(function () {


    if (masterCard.length === allCard.length) {
      alert('Winner Winner Chicken Dinner');
    }
    if (nextElement.firstElementChild.className === cardData) {
      e.target.classList.add('matched');
    }
    // try1
    arry2.forEach((card, index) => {

      nextElement.children[0].className = "";
      nextElement.children[0].classList = arry2[index];

    });
    e.target.classList.toggle('show');
  }), 700;
});

// shuffling array

function shuffle(array) {
  var currentIndex = array.length, temporaryValue, randomIndex;

  while (currentIndex !== 0) {
    randomIndex = Math.floor(Math.random() * currentIndex);
    currentIndex -= 1;
    temporaryValue = array[currentIndex];
    array[currentIndex] = array[randomIndex];
    array[randomIndex] = temporaryValue;
  }

  return array;
}
shuffle(arry);

arryy = [];

function playGame() {

  let deck = document.getElementById("cards").querySelectorAll('i');

  for (let i = 0; i < deck.length; i++) {
    arryy.push(deck[i].className);
  }

  shuffle(arryy);

  for (let i = 0; i < deck.length; i++) {
    deck[i].className = arryy[i];
  }
}
playGame();

// restart game

let reset = document.getElementById('reset');

reset.addEventListener('click', function (e) {
  playGame();
  count.innerText = 0;
  for (i = 0; i < deckCard1.length; i++) {
    deckCard1[i].classList.remove('show', 'matched');
  }
});
